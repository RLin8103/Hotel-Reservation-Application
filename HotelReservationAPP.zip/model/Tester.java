package model;

public class Tester {
  public static void main (String[] args) {
    Customer customer = new Customer("first", "second", "RLin8103@gmail.com");
    System.out.println(customer);
//    Customer customer = new Customer("first", "second", "email");
//    System.out.println(customer);
  }
}
